import React from 'react';


class ConfirmCheckIn extends React.Component {
    render() {
      return (
        <div >
             <p>
                 CheckIn Complete!!
            </p>
        </div>
      );
    }
  }
  
  export default ConfirmCheckIn;